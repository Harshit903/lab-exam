#include<linux/module.h>
static char *myname = "Hrashit CED17I042";
int init_module(void){
	printk("Your name from the parameter input is %s\n",myname);
	return 0;
}
void cleanup_module(void){
	printk("Module removed");
}
MODULE_LICENSE("GPL");
